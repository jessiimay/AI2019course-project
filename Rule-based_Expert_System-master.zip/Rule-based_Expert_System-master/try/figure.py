"""

"""

__author__ = 'liuyang'


class Figure:
    def __init__(self):
        self.figureType = None

    def set_type(self, figureType):
        self.figureType = figureType

    def get_type(self):
        return self.figureType